//header file for class Game; class that keeps track of stuff going on as the game is getting executed. 
#include <iostream>
using namespace std;
#include "Pokemon.h"
#include "Tile.h"
#include "Player.h"

//class to read map file, read pokemon file 

#include <iostream> //always include
using namespace std; //always include


#ifndef GAME_H
#define GAME_H

Class Game{
    private: //data members
        Tile map[][]; //double array of tiles; all the tiles w/ their row number, column number, and tile type
        

    public: //member functions
        Game(); //default constructor
        
        //executed once @ beginning of game: 
        readMap(string fileName); //fill data member map[][] 
        //getline from mapFile.txt, create a Tile class instance for every tile spot/x-y location
        readPokemon(string fileName);//getline from pokemonFile.txt, create a Pokemon class instance for every pokemon 
        
        //-----------setters----------------
        
        //-----------getters----------------
        string getTileTypeAt(int row, int column); //map[row][column].getType() function  
};
#endif