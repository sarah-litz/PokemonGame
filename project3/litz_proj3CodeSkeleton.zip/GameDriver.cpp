#include <iostream>
using namespace std;

/**
void StartGame(){ //loop that only runs once at very beginning of game
 GameBoard game1; 
 cout << welcome statements, prompt player for <username>; 
 Player player1;
 string username; 
 cin << username; 
  
 cin >> player1; 
 Player player1; 
  
 game1.readMap(map.txt) //read map file stored in separate txt file 
 game1.readPokemon(pokemon.txt) //read pokemon/stat txt file 
 
}
*/

beginGame(){
 
}
 

main(){
 /**create new Game object
  * game.readMap(filename) to get map info from file
  * fucntion readMap(){
     create Tile objects for every lcoation on map
  }
 
  * game.readPokemon(filename) to get pokemon info from file 
  create HazardTiles object{ 
  * create 15 new Player objects palyer(_isTrainer=true)//create the 15 trainers
  *   ~~set trainer info/stats~~not sure if this is random or not? 
  *   ~~ setLocationTrainer() at random for these tiles; this is
    * create 20 Pokemon objects //wild pokemon!! 
    * create 20 hazardTile objects //to keep track of locations of wild pokemon 
    *   ~~ setLocationPokemon() at random for these tiles; this is where the 20 wild pokemon exist.
  }
  * welcome statements, get username for player. 
  * create new Player object 
  * present 'username' with 4 options for their starter pokemon, have user choose option between 1-4. 
  *  (if number outside of this range is chosen, ensure that code doesn't breakdown.) 
  * Player newplayer; 
  * newPlayer.setActivePokemon("pokemonName from displayed options")
  * 
  * 
  * begin playing loop{
      present user w/ options for first move 
  }
  */

 
}
