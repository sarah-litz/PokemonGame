//class for player info/stats AND trainer info/stats throughout game execution
#include <iostream>
using namespace std;
#include "Pokemon.h"

#ifndef PLAYER_H
#define PLAYER_H

class Player
{
    private: 
        //data members: player stats go here
        int pokeballs; //initialized to 10 @game start 
        //pokeball = game "currency" 
        int badges; //end game if 6 collected
        int points; 
        Pokemon activePokemon; 
        Pokemon pokemonSuite[6]; //vector also? 
        Pokemon pokedex[]; //overflow from pokemonSuite ~~ vector maybe?? 
        bool isTrainer; 
    public: 
        //-----------setters
        Player(); //default constructor
        Player(_isTrainer); //add more? parameterized constructor
        setPokeballs();
        setBadges(); 
        setPoints(); 
        setActivePokemon(); 
        
        addtoSuite(); //max=6
        addtoPokedex(); //overflow pokemon
        //-----------getters

}