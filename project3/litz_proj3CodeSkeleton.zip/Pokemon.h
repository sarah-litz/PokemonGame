//class for pokemon info/stats 
#include <iostream>
using namespace std;

#ifndef PLAYER_H
#define PLAYER_H

class Pokemon
{
    private: 
        int hitPoints; 
        int attack; //strength of attack
        int defense; //strength/resistance against attacks
        int maxStrength; //maximum strength/resilience value of attacks and defense as they level up
        int speed; 
    public: 
        //--------setters 
        void setHitPoints(); 
        void setAttack(); 
        void setDefense(); 
        void setMaxStrength(); 
        void setSpeed(); 
        
        //---------getters
};
#endif
