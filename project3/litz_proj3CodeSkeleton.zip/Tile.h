#include <iostream>
using namespace std;

#ifndef TILE_H
#define TILE_H

//each instance stores info on ONE specific tile: its row,column,and type. 
class Tile{
    private: 
        int row; 
        int column; 
        string type; 
    public: 
        Tile(); 
        Tile(int _row,int _column, string _type);
        
        void setRow(int _row); 
        void setColumn(int _column); 
        void setType(string _type);
        
        int getRowNum(); 
        int getColumnNum(); 
        string getType(); 
}; 
#endif